import Footer from "./pages/Footer";
import Header from "./pages/Header";
import Home from "./pages/Home";
import Product from "./pages/Product";
import About from "./pages/About";
import SignUp from "./pages/SignUp";
import Login from "./pages/Login";
import Register from "./pages/Register";
import { BrowserRouter, Routes, Route } from "react-router-dom";

function App() {
  return (
    <div style={{ minHeight: "100vh" }}>
      <div className="max-w-[1460px] mx-auto">
        <BrowserRouter>
          <Header />
          <Routes>
            {/* <Route path="/" element={<Home />} /> */}
            <Route path="/home" element={<Home />} />
            <Route path="/product" element={<Product />} />
            <Route path="/about" element={<About />} />
            <Route path="/signUp" element={<SignUp />} />
            <Route path="/register" element={<Register />} />

             <Route path="/login" element={<Login />} />


          </Routes>
          <Footer />
        </BrowserRouter>
      </div>
    </div>
  );
}

export default App;
