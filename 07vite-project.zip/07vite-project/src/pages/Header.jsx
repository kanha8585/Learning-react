import { useState } from "react";
import "./Header.css";
import {Link} from "react-router-dom";


function Header(){
    const [showsearchInput,setShowsearchInput]=useState(false)
    const[inputval,setInputValue]=useState("")


    function handleonMouseOver(){
        setShowsearchInput(true)
    }

    function handleonMouseOut(){
        setInputValue("")
        setShowsearchInput(false)
    }

    function handleChange(e){
        setInputValue(e.target.value)

    }



    return(
        <>
         <div className="header">
            <h2 className="logo"><Link to={"/"}>E-commerce</Link></h2>
            <div className="headerRight">
            <div className="fromDiv">
                <form onMouseEnter={handleonMouseOver} onMouseLeave={handleonMouseOut}>
                     <input type="text"className={showsearchInput ? "showInput" : "closeInput"} placeholder="Search..." 
                        onChange={handleChange}value={inputval} />
                </form>
                </div>  
                <ul className="headerUl">
                    <li><Link to="/Product" className="text-black">Product</Link></li>
                    <li><Link to="/About" className="text-black">About</Link></li>
                    <li><Link to="/SignUp" className="text-black">SignUp</Link></li>
                    
                </ul> 
            </div>
         </div>
         <div className="min-h-[80px]"></div>
        </>
    )
}

export default Header;

