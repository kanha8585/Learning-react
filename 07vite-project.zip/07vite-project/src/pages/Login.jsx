 import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import "./Login.css";

function Login() {
    let navigate = useNavigate();
    const [userProfile, setUserProfile] = useState({
        email: "",
        password: ""
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setUserProfile(prevState => ({
            ...prevState,
            [name]: value
        }));
    };

    function handleRegister(e) {
        e.preventDefault();
        console.log(userProfile);

        setUserProfile({
            email: "",
            password: ""
        });

        navigate("/login");
    }

    return (
        <div className='register'>
            <div className='container'>
                <form onSubmit={handleRegister}>
                    <input type='email'  name='email'  placeholder='Enter Your Email'  value={userProfile.email}  onChange={handleChange}  required /><br />

                    <input  type='password'name='password'placeholder='Enter Password' value={userProfile.password} onChange={handleChange} required /><br />

                    <button className='btn' type='submit'>Login</button>
                </form>
            </div>
        </div>
    );
}

export default Login;
