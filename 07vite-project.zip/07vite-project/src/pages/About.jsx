import React from 'react'
import "./About.css";

 
     

// function About() {
//   return (
//     <div style={styles.container}>
//       <h1 style={styles.heading}>About Us</h1>
//       <p style={styles.paragraph}>
//         Welcome to our website! We are committed to providing the best service
//         and creating solutions that make your life easier. Our team is made up
//         of passionate individuals working together to bring innovative ideas to
//         life.
//       </p>

//       <div style={styles.infoSection}>
//         <div style={styles.card}>
//           <h2>Our Mission</h2>
//           <p>
//             Deliver quality products and services with a focus on customer
//             satisfaction.
//           </p>
//         </div>

//         <div style={styles.card}>
//           <h2>Our Vision</h2>
//           <p>
//             Become a leading company that sets benchmarks in innovation and
//             excellence.
//           </p>
//         </div>
//       </div>
//     </div>
//   );
// }

// const styles = {
//   container: {
//     padding: "20px",
//     maxWidth: "1000px",
//     margin: "0 auto",
//     textAlign: "center",
//   },
//   heading: {
//     fontSize: "2.5rem",
//     marginBottom: "20px",
//     color: "#333",
//   },
//   paragraph: {
//     fontSize: "1.1rem",
//     color: "#555",
//     marginBottom: "30px",
//   },
//   infoSection: {
//     display: "flex",
//     gap: "20px",
//     flexWrap: "wrap",
//     justifyContent: "center",
//   },
//   card: {
//     background: "#431ab3ff",
//     padding: "20px",
//     borderRadius: "10px",
//     flex: "1 1 250px",
//     boxShadow: "0 4px 6px rgba(0,0,0,0.1)",
//   },
// };

 

  


// export default About

function About() {
  return (
    <div className="about-section">
      <div className="about-content">
        <img src="https://picsum.photos/seed/company/300/200" alt="Company" />
        <div>
          <h2>About Our Company</h2>
          <p>We are a leading provider of quality products serving customers worldwide. Our mission is to deliver reliable and stylish products at affordable prices. Customer satisfaction is our top priority.</p>
          <p>Contact Us:</p>
          <p>Phone: +91-9876543210</p>
          <p>Email: contact@company.com</p>
        </div>
      </div>
    </div>
  );
}

export  default About;