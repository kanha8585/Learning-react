import React from 'react'
import Header from './Header'
import Footer from './Footer'
import heroImage from "../assets/image/heroImage.webp"

function Home() {
    return (
        <>
            <div className='w-full'>
                <div className='relative w-full'>
                    <img src={heroImage} alt='hero' />
                    <div className='absolute right-[6rem] bottom-[8rem] w-1/4'>
                        <h2 className='text-white text-3xl pb-3 font-bold'>SMART SHOPPING</h2>
                        <button className='px-3 py-1 bg-white rounded-2xl '>SHOP NOW</button>


                    </div>
                </div>
            </div>

        </>


    )
}



export default Home