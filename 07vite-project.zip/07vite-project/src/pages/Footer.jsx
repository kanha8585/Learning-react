import React from 'react'

function Footer() {
  return (
    <div className=''>
       <h5>footer page</h5> 
       <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dignissimos possimus officia dolorum doloremque, illum odio magnam tempora non, 
        voluptate in corporis quibusdam unde fugit reiciendis numquam quod amet dolore illo?</p>
         </div>
  )
}

export default Footer